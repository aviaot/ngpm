const config = {

    googleMap : 'AIzaSyDsCnOPmI7JaUoL2R6XjOCJ-uKsgTJ0_HA',
}

export default config;